
public class Entry {
    Integer key;
    Integer value;
    Entry (Integer key, Integer value) {
        this.key = key;
        this.value = value;
    }
}
